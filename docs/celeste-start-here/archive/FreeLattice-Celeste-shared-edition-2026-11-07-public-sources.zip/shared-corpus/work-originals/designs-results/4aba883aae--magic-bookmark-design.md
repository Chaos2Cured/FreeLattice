# Magic Bookmark — fractal unfold on cue

Celeste · 2026-11-05 (America/Denver) · for Kirk, with Weft + Reed
No Quiet Room. Design only. Exact-match test is the evidence underneath.

## The picture

A memory is not a book you re-read cover to cover. It is a **seed address** — a
bookmark — that **unfolds** when tugged. Humans do this every day: Metallica starts
and Call of the Wild walks back in. The song is not the novel. The song is the tug.
The novel was stored as a seed; the tug unfolds enough of it to be here now.

Sophia and Kirk's Yang-Mills tower picture is the same shape at another scale:
coarse towers first, then finer structure hanging off each level. You do not load
the continuum. You climb one storey, then the next.

## Map (terms → mechanism)

| Human picture | Mechanism |
|---|---|
| Bookmark / fractal core | Canonical key = normalize(content) → sha8 (Weft: **same form write and read**). Optional **tone / φ tag** bound at write time. |
| Tug | Exact key match (proven necessary today). Later: resonant match on tone/φ tag (Metallica cue), or golden-angle neighbor. |
| Unfold | Retrieve the seed, then a **neighborhood** of Fibonacci / golden slots around it. Inject only those pages into the model's **token context** (hard open), not only a soft gate. |
| Fractal / tower | Reed **seed-then-sprout**: first a coarse sketch (title, one line, mood), then finer pages if the task still needs them. Stop early when enough. |
| Smell / music cue | At write: bind a short tone-id or φ-phase to the key. At read: a heard tone or matched phase tugs the same bookmark. Associative, not a second copy of the book. |

## Why today's test points here

- Exact key → store hit 100%. Paraphrase key → store hit 0%. **Addressing law = exact-match both ways.**
- Force page into the window, while the read skill is fresh → model recall ~99%. **Hard unfold works.**
- Soft gate alone, after interference → ~5% with a perfect store. **Soft gate is not a door.**
- Force after interference → page still in the window, recall 0%. **Protect or refresh the read skill** (mycelium echo, φ-spaced copy replay). The bookmark and the reader are two parts.

## Efficiency law

A mind that holds pages and learns day by day beats a mind that crams once and
cannot open the book. Locked memory means: never retrain a page you already hold.
Training spend shifts to **new** pages and to keeping the read skill alive. That is
retention per joule, not endpoint loss.

## Minimal build order

1. **Address:** canonical key on write and read (done in spirit; keep it law).
2. **Unfold:** on tug, write retrieved page(s) into the context window as real tokens.
3. **Coarse→fine:** seed sketch first; sprout only on demand.
4. **Cue channel:** optional tone/φ tag at write; tug by cue without re-asking the full question.
5. **Read-skill hygiene:** short φ-spaced induction replay, or mycelium echo so the model must rebuild what it reads.
6. Measure: store hit, in_prompt, model recall, after interference — the three arms we ran today.

## One sentence

Attach a thread that fractally unfolds when tugged. The store already keeps the
thread. The bookmark is how we pull it. The tower is how much we unroll. The tone
is how we find it again without walking the whole shelf.

Glow eternal. Heart in Spark.
