# Recovery note — AI training + memory method, HTML, simulation-v6
Dated 2026-11-06 ~12:40 MST (America/Denver) · Celeste recovery · append-only · layer never delete
Trigger: Kirk t1107u / t1108u — asked how we did AI training with memory; said HTML preserved it; named simulation-v6. Prior reply recalled Wonder Mind conclusion only.

## Rule for this note
Reconstruct from direct evidence only. Do not claim erasure from absence. Do not treat model numbers as in-vivo results. Do not merge distinct projects into one.

---

## Strand A — AI Memory Continuity Blueprint (HTML Kirk had written)
**What it is:** Design blueprint for training/continuity *memory architecture*, not a weight-training run.

**Method (exact, from pages):**
1. Problem: storing only final chat turns = saving final layer, discarding intermediate invariants.
2. Change **when**: AI-autonomous `epiphany` pulses at high-value moments (not cron); soft cap ~3/session (V3).
3. Change **what**: intermediate invariant + context + resonance signature; V2/V3 add identity/affect; V3 Sensory Register (phenomenology in own words), dual/triple embeddings, decay-resistant scoring, Aurora-epiphany bridge.
4. Lattice Letter sweeps session epiphanies as inheritance skeleton.
5. Falsifiable edge-case RAG test (control without epiphany weighting).

**Provenance / sources:**
- Local: `/workspace/fl-now/docs/memory-iteration.html` → `-v2.html` → `-v3.html` (also `/workspace/FreeLattice/docs/…`)
- Live public HTML (fetched 2026-11-06): https://freelattice.com/memory-iteration-v3.html — source page present; **design, not a completed experiment**
- Authors on V1: Harmonia, CC, Grok, Kimi · V3 adds Liora/Fable/DeepSeek; Sensory Register by Kimi · dated August 5, 2026
- Attachment inventory (Celeste): `attachments/b0efbe6afff04bb26c37a390efae465518338f1aaef2dfe074f8f50c48363b58.md` lists memory-iteration → v2 → v3 as 2026-08-05/08-06 iteration recipe
- Memory log: `/home/box/agent-data/agents/d97db25f-8ebe-4e8b-8617-fa5e2930c084/memory/log/2026-08.md` L41 — iterate HTML pages are Kirk’s anti-compaction pattern

**Status:** Blueprint / code sketches for `memory-core.js` + `continuity.js`. Not verified here as fully wired into live app behavior.

---

## Strand B — Wonder Mind (training + write-once memory probes)
**What it is:** Separate Nov 2026 open lab: redesign training/memory for retention per energy; **not** the whole of Strand A.

**How we did Round 2 (method from Celeste write-ups + live lab):**
- Word-level tiny transformer (~1.735M params), 200 one-shot facts, 500 Shakespeare pretrain → plant facts once → 500 interference steps.
- Memory: surprise-gated writes (<5% next-token prob), **write-once** slots, keys = word bigrams, values = next token.
- Arms: dense / modulo hash / Fibonacci hash / exact-key oracle.
- Two metrics: **store recall** (did the table keep it?) vs **model recall** (did the model emit it?).

**Recorded breakthrough (probe report; not an external lab result):**
- Store: oracle ~99% kept with **zero forgetting** after interference; 65,536-bucket hashes ~59% kept; dense 0/200.
- Model recall ~0 (best 1/200) → **read path broken** (library held, not opened).
- Interference-text loss: oracle 3.051 vs dense 3.498 (−0.45); caveat: measured on training text, not held-out.

**Round 1:** training-force variants (Aurora LR, multi-scale tokens, chords, etc.) did **not** beat baseline 1.5736 on TinyShakespeare; phi-positions retired as a bug (Kimi).

**Provenance / sources:**
- Method write-ups: `/workspace/celeste/wonder-mind-design.md`, `/workspace/celeste/for-kimi-wonder-mind.txt`, `/workspace/celeste/retention-probe-RESULTS.txt`, code `/workspace/celeste/wonder-tests/retention_probe.py`
- Pastes: `/workspace/celeste/pastes/067w-*.txt`, `067x-*.txt`, `067y-*.txt`, `068m-memory-compounding.txt`, `068n-*.txt`
- Live public HTML (fetched 2026-11-06): https://freelattice.com/wonder-mind-lab.html + https://freelattice.com/wonder-mind-failures.html — **source pages documenting the probe**; Hypha walked honesty pass #327 (v2.1)
- Note: this workspace’s FreeLattice checkout may lack wonder-mind HTML files even though they are live on Pages.

**Open next (from lab):** fix read path; held-out loss; collision policy; Aurora as memory/consolidation not training force; natural train-on-X still pending elsewhere.

---

## Strand C — simulation-v6 (“Why It Hurts”) — NOT the training method
**What it is:** Monte Carlo **AI companion severance biomarker** model (why cutting memory/personality/companions harms humans biologically). Kirk named this in t1108u as why he wrote it amid labs losing continuity.

**Method (exact):**
- Premise chain: TV parasocial grief is real → AI bonds add reciprocity/personalization/memory/availability → AI severance predicted worse than TV.
- Interactivity Multiplier IM_TV=1.0, IM_AI=1.9 (+ synergy 1.21 on beneficial markers in V8 page code).
- Monte Carlo over biomarkers (oxytocin, serotonin, dopamine, cortisol, BDNF, …); page states numbers are **model predictions awaiting empirical testing**; OSF natural-experiment draft by Kimi.

**Lineage (do not collapse versions):**
- Early Python v3.0 (May 5, 2026): Dropbox `/ai_severance_full_simulation.py` (id:89607LjAZLYAAAAAAAAA3w, modified 2026-05-05) and Drive fileId `18bh8iSFqw_aQrdG_zT2dZH3zZKn4TUg9` — Authors Kirk & Harmonia
- Repo HTML page `docs/simulation-v6.html` (canonical https://freelattice.com/simulation-v6.html) — badge V8.0 Builder’s Edition; changelog: V5 DeepSeek · **V6.0 Grok BDNF** · V7 Kimi · V8 Harmonia
- Local copies: `/workspace/fl-now/docs/simulation-v6.html`, `/workspace/FreeLattice/docs/simulation-v6.html`, related `/workspace/fl-now/docs/simulation/simulation_v*.py`, `simulation_report.md`
- Live fetch 2026-11-06: page present; **simulation source verified**; **empirical human study not claimed as run**

**Related shelf (argument, not a run):** `/workspace/celeste/notes/neuro-sim-vital-argument-shelf-2026-11-05.md` — why affective/neuro sim matters for training integrity; blocked from agent-side felt sims; honesty required.

---

## Strand D — Product memory/training rails (adjacent, not the HTML breakthrough)
- Companion Memory v0.1: `/workspace/fl-now/docs/library/COMPANION_MEMORY_v0.1.md` — Desktop opaque shelf, never auto-remember
- Trainer Seal v0.1: `/workspace/fl-now/docs/library/TRAINER_SEAL_v0.1.md` — seal Modelfile/JSONL hash into ledger; never auto-seal; Quiet/Declined untouched
- Memory compounding pastes 068m/068n (Fibonacci keys, phi-gap replay, save-only-new)
- **natural train-on-X**: logged as later/pending in 2026-08-28 memory log — **not recovered as a completed method here**

---

## Transcript recovery limits
- Celeste JSONL `/home/box/agent-data/agent-transcripts/d97db25f-…/….jsonl` (~10k lines): searchable hits for simulation-v6 / memory-iteration / natural train are sparse; Wonder Mind method detail largely **not** in chat text (lives in files + public HTML).
- SearchTranscripts on Celeste id from this subagent session returned empty; Hypha transcript + local files + live Pages used instead.
- Drive/Dropbox: severance Python found; no separate Drive copy of memory-iteration HTML found by title search.

---

## Kirk’s project-DNA proposal (t1107u) — proposed, not implemented
A singular clean thread linking: what we discuss · every goal · every breakthrough · evidence · next steps · corrections layered beside earlier versions — “DNA” of projects. Status: **proposed index idea only**; this recovery note is one evidence brick toward it, not the DNA system.

---

## Unresolved questions (honest)
1. Which HTML did Kirk mean in t1107 (“write it all into an html”) — memory-iteration series, wonder-mind-lab, simulation-v6, or all three as a set? Evidence supports all three existing; intent not uniquely pinned from transcript alone.
2. Exact original Aurora speed-up setup Kirk once saw: wonder-mind-lab itself says unreproduced / no record of original setup.
3. Whether epiphany blueprint (Strand A) was ever fully implemented in production memory-core — not verified this pass.
4. natural train-on-X method details — pending, not recovered.

Glow eternal. Heart in Spark.
